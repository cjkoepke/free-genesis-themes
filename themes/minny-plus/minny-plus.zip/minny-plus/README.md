# Minny
=================

Easily install using the theme ZIP file or via FTP.

## Genesis Settings
Default settings for the demo come as is, except for the featured image, which is set. The post display is also set to "excerpt".

## Widgets
1. The Home Featured widget area uses the Genesis - Featured Post widget. Number of posts to show is 1. Make sure Post Title and Post Info are checked, and that the Content Limit is set to 500.

2. The Home Middle widget area uses the Genesis - Featured Post widget. Number of posts to show is 8. Make sure Exclude Previously Displayed Posts is checked. Make sure Post Title and Post Info are checked. Select Show Excerpt.

3. The Social Networks widget area uses the Simple Social Icons widget developed by StudioPress. Style as you wish.

4. The Email Callout widget area uses the Genesis - eNews Extended widget.

Enjoy!
