Minny
=================

Easily install using the Minny.zip file. <a href="http://demo.calvinkoepke.com/minny/" target="_blank">DEMO THEME</a>.

## Genesis Settings
Default settings for the demo come as is, except for the featured image, which is set. The post display is also set to "excerpt".

Enjoy!
